package cybersoft.javabackend.java12.gira.user.util;

public enum UserStatus {
	DELETED,
	TEMPORARY_BLOCKED,
	PERNAMENT_BLOCKED,
	ACTIVE
}
