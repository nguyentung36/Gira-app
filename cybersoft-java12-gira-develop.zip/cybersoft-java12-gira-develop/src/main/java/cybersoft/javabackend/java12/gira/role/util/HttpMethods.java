package cybersoft.javabackend.java12.gira.role.util;

public enum HttpMethods {
	GET,
	POST,
	PUT,
	DELETE,
	PATCH,
	OPTION,
	HEAD,
	LEAD
}
