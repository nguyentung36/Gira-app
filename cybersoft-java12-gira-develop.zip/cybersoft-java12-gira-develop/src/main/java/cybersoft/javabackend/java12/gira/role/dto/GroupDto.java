package cybersoft.javabackend.java12.gira.role.dto;

public interface GroupDto {
	// projection
	public Long getId();
	public String getName();
	public String getDescription();
}
